// 
//  SNRBaseModel.h
//  SyneriseSDK
//
//  Created by Synerise
//  Copyright (c) 2020 Synerise. All rights reserved.
//

NS_ASSUME_NONNULL_BEGIN

/**
 * @class SNRBaseModel
 */

NS_SWIFT_NAME(BaseModel)
@interface SNRBaseModel : NSObject

@end

NS_ASSUME_NONNULL_END
